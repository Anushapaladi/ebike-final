package com.ebike.payment;

public interface Command {
    void execute();
}
