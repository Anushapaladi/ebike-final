package com.ebike.order;

public abstract class Order {
	
	public abstract String orderDetails();

	public abstract int cost();
}
