E Bike Project:

This is simple Project to Demonstrate the Design Patterns in Designing the E-Bike system.

There are 4 packages for the design patterns. 

Pre-Requisite:
1) Java Should be available in the machine with Version > 1.8
2) An IDE is more help in running the Project.

How to Run a Project:
==========================================
Steps:
==========================================
1) Once the Project is Imported to any IDE, there is package named "com.ebike"

2) Under the "com.ebike", run the file Named "MainClassTestDriver.java".