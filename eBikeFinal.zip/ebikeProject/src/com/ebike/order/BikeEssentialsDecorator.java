package com.ebike.order;

public abstract class BikeEssentialsDecorator extends Order {
	public abstract String orderDetails();
}
